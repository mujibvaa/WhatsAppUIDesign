package com.mujib.mujibcse225;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

public class SplashActivity extends AppCompatActivity {


    private int SLEEP_TIMER = 3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        SplashScreen splashscreen = new SplashScreen();
        splashscreen.start();
    }

    private class SplashScreen extends Thread{


        public void run() {
            try {
                sleep(SLEEP_TIMER*1000);

            }
            catch (InterruptedException e){
                e.printStackTrace();
            }
            Intent intent = new Intent(SplashActivity.this,MainActivity.class);
            startActivity(intent);
            SplashActivity.this.finish();
        }
    }
}

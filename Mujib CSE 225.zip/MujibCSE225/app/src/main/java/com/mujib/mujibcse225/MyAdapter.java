package com.mujib.mujibcse225;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;


import java.util.ArrayList;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class MyAdapter extends ArrayAdapter<ChatItem> {


    public MyAdapter(Context context, List<ChatItem> chatItemList) {

        super(context, R.layout.listviewtemp, chatItemList);
        this.chatItemList = chatItemList;
    }

    List<ChatItem> chatItemList = new ArrayList<>();




    public View getView(int position,View convertView,ViewGroup parent) {

        LayoutInflater inflater = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        final  View row = inflater.inflate(R.layout.listviewtemp,parent,false);

        CircleImageView circleImageView = row.findViewById(R.id.profile_image);
        TextView nametext = row.findViewById(R.id.username);


        circleImageView.setImageResource(chatItemList.get(position).getImage());
        nametext.setText(chatItemList.get(position).getName());





        return row;
    }
}

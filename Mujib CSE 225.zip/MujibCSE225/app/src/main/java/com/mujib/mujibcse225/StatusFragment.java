package com.mujib.mujibcse225;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;


public class StatusFragment extends Fragment {

    ListView chatlist;
    static List<ChatItem> chatItemList;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_status, container, false);


        chatlist = (ListView) view.findViewById(R.id.chatlistv);

        chatItemList = new ArrayList<>();

        chatItemList.add(new ChatItem("Cristina", R.drawable.c));
        chatItemList.add(new ChatItem("Suzana", R.drawable.d));
        chatItemList.add(new ChatItem("Mr.Grey", R.drawable.e));
        chatItemList.add(new ChatItem("Clara", R.drawable.h));
        chatItemList.add(new ChatItem("Alex Panda", R.drawable.f));
        chatItemList.add(new ChatItem("Piter Parker", R.drawable.g));
        chatItemList.add(new ChatItem("Alexa", R.drawable.a));
        chatItemList.add(new ChatItem("Alexa", R.drawable.a));
        chatItemList.add(new ChatItem("John Doe", R.drawable.b));
        chatItemList.add(new ChatItem("John Doe", R.drawable.b));
        chatItemList.add(new ChatItem("Cristina", R.drawable.c));
        chatItemList.add(new ChatItem("Suzana", R.drawable.d));
        chatItemList.add(new ChatItem("Mr.Grey", R.drawable.e));
        chatItemList.add(new ChatItem("Clara", R.drawable.h));
        chatItemList.add(new ChatItem("Alex Panda", R.drawable.f));
        chatItemList.add(new ChatItem("Piter Parker", R.drawable.g));


        StatusAdapter statusAdapter = new StatusAdapter(getContext(), chatItemList);
        chatlist.setAdapter(statusAdapter);

        return view;
    }
}

package com.mujib.mujibcse225;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import androidx.viewpager.widget.ViewPager;
import androidx.appcompat.widget.Toolbar;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.tabs.TabLayout;

import java.util.ArrayList;

import static com.mujib.mujibcse225.R.*;


public class MainActivity extends AppCompatActivity {

    FloatingActionButton floatingActionButton;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(layout.activity_main);


        Toolbar toolbar = findViewById(id.toolbar1);
        setSupportActionBar(toolbar);

        floatingActionButton = findViewById(id.floating_action_button);




        final TabLayout tabLayout = findViewById(id.tab_layout);
        final ViewPager viewPager = findViewById(id.view_pager);






        ViewPagerAdapter viewPagerAdapter = new ViewPagerAdapter(getSupportFragmentManager());
        viewPagerAdapter.addFragment(new ChatFragment(), "Chats");
        viewPagerAdapter.addFragment(new StatusFragment(), "Status");
        viewPagerAdapter.addFragment(new CallFragment(), "Calls");

        viewPager.setAdapter(viewPagerAdapter);


        tabLayout.setupWithViewPager(viewPager);



      tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
          @Override
          public void onTabSelected(TabLayout.Tab tab) {

              switch (tab.getPosition()){

                  case 0:
                      floatingActionButton.setImageResource(drawable.ic_message_black_24dp);
                      floatingActionButton.setOnClickListener(new View.OnClickListener() {
                          @Override
                          public void onClick(View v) {
                              Toast.makeText(getApplicationContext(),"Chat Button",Toast.LENGTH_SHORT).show();
                          }
                      });
                      break;

                  case 1:
                      floatingActionButton.setImageResource(drawable.ic_mood_black_24dp);
                      floatingActionButton.setOnClickListener(new View.OnClickListener() {
                          @Override
                          public void onClick(View v) {
                              Toast.makeText(getApplicationContext(),"Status Button",Toast.LENGTH_SHORT).show();
                          }
                      });
                      break;

                  case 2:
                      floatingActionButton.setImageResource(drawable.ic_call_black_24dp);
                      floatingActionButton.setOnClickListener(new View.OnClickListener() {
                          @Override
                          public void onClick(View v) {
                              Toast.makeText(getApplicationContext(),"Call Button",Toast.LENGTH_SHORT).show();
                          }
                      });
                      break;
              }
          }

          @Override
          public void onTabUnselected(TabLayout.Tab tab) {

          }

          @Override
          public void onTabReselected(TabLayout.Tab tab) {

          }
      });



    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menulayout,menu);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        int id = item.getItemId();

        if (id == R.id.contact){
            Toast.makeText(getApplicationContext(),"You Have Clicked on Contacts",Toast.LENGTH_SHORT).show();
        }

        else if (id == R.id.search){
            Toast.makeText(getApplicationContext(),"You Have Clicked on Search",Toast.LENGTH_SHORT).show();
        }

        else if (id == R.id.logout){
            Toast.makeText(getApplicationContext(),"You Have Clicked on Logout",Toast.LENGTH_SHORT).show();
        }




        return true;
    }

    class ViewPagerAdapter extends FragmentPagerAdapter {

        private ArrayList<Fragment> fragments;
        private ArrayList<String> titles;

        ViewPagerAdapter(FragmentManager fm){

            super(fm);

            this.fragments=new ArrayList<>();
            this.titles=new ArrayList<>();
        }

        @Override
        public Fragment getItem(int position) {
            return fragments.get(position);
        }

        @Override
        public int getCount() {
            return fragments.size();
        }


        public void addFragment(Fragment fragment,String title){

            fragments.add(fragment);
            titles.add(title);

        }

        @Nullable
        @Override
        public CharSequence getPageTitle(int position) {
            return titles.get(position);



        }
    }



}
